<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function show(User $user){
        return view('profiles.show', compact('user'));
    }

    public function edit(User $user){

        if($user->isNot(auth()->user())){
            abort(404);
        }
        return view('profiles.edit', compact('user'));
    }

    public function update(User $user){
        $attributes = request()->validate([
            'name' => ['string', 'required', 'max:255'],
            'email' => ['string', 'required', 'max:255', 'email'],
            'avatar' => ['file'],
            'password' => ['string', 'required','min:8', 'max:20']
        ]);

        if(request('avatar')){
            $attributes['avatar'] =  request('avatar')->store('avatars');
        }
        

        $user->update($attributes);
        
        return redirect($user->path());
    }
}
