<?php

use App\Http\Controllers\ExploreController;
use App\Http\Controllers\FollowsController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\TweetController;
use Illuminate\Support\Facades\Route;



Route::get('/welcome', function () {
    return view('welcome');
});
Route::get('/', [TweetController::class, 'index'])->middleware(['auth'])->name('dashboard');
Route::post('/tweets', [TweetController::class, 'store']);


Route::get('/profiles/{user:name}', [ProfileController::class, 'show'])->name('profile');
Route::get('/profiles/{user:name}/edit', [ProfileController::class, 'edit']);
Route::patch('/profiles/{user:name}', [ProfileController::class, 'update']);


Route::post('/profiles/{user:name}/follow', [FollowsController::class, 'store']);

Route::get('/explore', [ExploreController::class, 'index'])->middleware(['auth']);


require __DIR__.'/auth.php';
