<h3 class="font-bold text-xl mb-4">Following</h3>

<ul>
    <?php $__empty_1 = true; $__currentLoopData = auth()->user()->follows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <li class="mb-4">
            <div>
                <a href="<?php echo e(route('profile', $user)); ?>"  class="flex items-center text-sm">
                    <img class="rounded-full mr-2" src="https://i.pravatar.cc/40" alt="">
                    <?php echo e($user->name); ?>

                </a>
            </div>
        </li>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No  friends yet!</p>
    <?php endif; ?>
</ul><?php /**PATH G:\Laravel\tweety\resources\views/_friends-list.blade.php ENDPATH**/ ?>