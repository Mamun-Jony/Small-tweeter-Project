<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
<?php $__env->startSection('content'); ?>
    <header class="relative">
        <img src="/images/backg.jpg" alt="" class="mb-7">
    </header>
    <div class="row">
        <div class="lg:flex-1 lg:mx-10" style="max-width:700px">
            <div class="flex mb-4 font-bold">
                <img class="mr-4" src="<?php echo e(asset('storage/' . $user->avatar ?: '/storage/demo.jpg')); ?>" width="100px" height="100px" alt="">
                <h2 class="font-bold text-2xl mb-4"><?php echo e($user->name); ?></h2>
            </div>

            <p class="text-sm mb-10">Joined <?php echo e($user->created_at->diffForHumans()); ?></p>
        </div>
        
        <div class="mb-10 flex">
            <?php if(auth()->user()->is($user)): ?>
                <a href="<?php echo e($user->path('edit')); ?>" class=" mr-5 bg-blue-500 rounded-lg py-2 px-2 text-white shadow">Edit Profile</a>
            <?php endif; ?>

            <?php if (! (auth()->user()->is($user))): ?>
                
                <form action="/profiles/<?php echo e($user->name); ?>/follow" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="bg-blue-500 rounded-lg py-2 px-2 text-white shadow">
                        <?php echo e(auth()->user()->following($user) ? 'Unfollow Me' : 'Follow Me'); ?>

                    </button>
                </form>
            <?php endif; ?>

        </div>



        <div class="lg:flex-1 lg:mx-10" style="max-width:700px">
            <?php echo $__env->make('_timeline',[
                'tweets' => $user->tweets
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>     
    
    
        <div class="lg:w-1/6 bg-blue-100 rounded-lg p-4">
                <?php echo $__env->make('_friends-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH G:\Laravel\tweety\resources\views/profiles/show.blade.php ENDPATH**/ ?>