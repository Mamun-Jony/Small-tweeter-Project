<x-app-layout>
    <x-slot name="header">
@section('content')
    <div class="lg:flex lg:justify-between">

            <div>
                @foreach ($users as $user)
                    <a href="{{ $user->path() }}" class="flex items-center mb-5">
                        <img src="{{ $user->avatar ?: '/images/demo.jpg' }}" alt="{{ $user->name }}" width="60px" class="mr-4 rounded">

                        <div>
                            <h4 class="font-bold">{{ $user->name }}</h4>
                        </div>
                    </a>
                @endforeach
            </div>
            <div class="lg:w-1/6 bg-blue-100 rounded-lg p-4">
                    @include('_friends-list')
            </div>
     </div>

@endsection

</x-app-layout>
