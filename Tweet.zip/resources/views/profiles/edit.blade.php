<x-app-layout>
    <x-slot name="header">
@section('content')
    <div class="lg:flex lg:justify-between">
                <form action="{{ $user->path() }}" method="POST"  enctype="multipart/form-data">
                    @csrf
                    @method('PATCH')

                    <div class="mb-5 w-full">
                        <label for="name" class="block mb-2 uppercase font-bold text-xs texxt-gray-700">Name</label>
                        <input class="border border-fray-500 p-2 w-full" type="text" name="name" id="name" value="{{ $user->name }}" required>

                        @error('name')
                            <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="mb-5">
                        <label for="email" class="block mb-2 uppercase font-bold text-xs texxt-gray-700">Email</label>
                        <input class="border border-fray-500 p-2 w-full" type="email" name="email" id="email" value="{{ $user->email }}" required>

                        @error('email')
                            <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="mb-5">
                        <label for="avatar" class="block mb-2 uppercase font-bold text-xs texxt-gray-700">Avatar</label>
                        <input class="border border-fray-500 p-2 w-full" type="file" name="avatar" id="avatar" value="{{ $user->avatar }}">

                        @error('avatar')
                            <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="mb-5">
                        <label for="password" class="block mb-2 uppercase font-bold text-xs texxt-gray-700">Password</label>
                        <input class="border border-fray-500 p-2 w-full" type="password" name="password" id="password" required>

                        @error('password')
                            <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
                        @enderror
                    </div>

                    <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full">Submit</button>
                </form>

            <div class="lg:w-1/6 bg-blue-100 rounded-lg p-4">
                    @include('_friends-list')
            </div>
     </div>

@endsection

</x-app-layout>
