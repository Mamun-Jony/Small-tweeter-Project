<x-app-layout>
    <x-slot name="header">
@section('content')
    <header class="relative">
        <img src="/images/backg.jpg" alt="" class="mb-7">
    </header>
    <div class="row">
        <div class="lg:flex-1 lg:mx-10" style="max-width:700px">
            <div class="flex mb-4 font-bold">
                <img class="mr-4" src="{{ asset('storage/' . $user->avatar ?: '/storage/demo.jpg') }}" width="100px" height="100px" alt="">
                <h2 class="font-bold text-2xl mb-4">{{ $user->name }}</h2>
            </div>

            <p class="text-sm mb-10">Joined {{ $user->created_at->diffForHumans() }}</p>
        </div>
        
        <div class="mb-10 flex">
            @if (auth()->user()->is($user))
                <a href="{{ $user->path('edit') }}" class=" mr-5 bg-blue-500 rounded-lg py-2 px-2 text-white shadow">Edit Profile</a>
            @endif

            @unless (auth()->user()->is($user))
                
                <form action="/profiles/{{ $user->name }}/follow" method="POST">
                    @csrf
                    <button type="submit" class="bg-blue-500 rounded-lg py-2 px-2 text-white shadow">
                        {{ auth()->user()->following($user) ? 'Unfollow Me' : 'Follow Me'  }}
                    </button>
                </form>
            @endunless

        </div>



        <div class="lg:flex-1 lg:mx-10" style="max-width:700px">
            @include('_timeline',[
                'tweets' => $user->tweets
            ])
        </div>     
    
    
        <div class="lg:w-1/6 bg-blue-100 rounded-lg p-4">
                @include('_friends-list')
        </div>
    </div>

@endsection

</x-app-layout>
