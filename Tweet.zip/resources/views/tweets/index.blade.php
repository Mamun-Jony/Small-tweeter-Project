<x-app-layout>
        <x-slot name="header">
@section('content')
        <div class="lg:flex lg:justify-between">

                <div class="lg:flex-1 lg:mx-10" style="max-width:700px">
                        @include('_public-tweet-panel')

                <div class="border border-gray-300 rounded-lg">
                        @forelse ($tweets as $tweet)
                                @include('_tweet') 
                                
                                @empty
                                        <p class="p-4 font-bold">No tweet Yet!</p>
                        @endforelse             
                </div>
                </div>
                <div class="lg:w-1/6 bg-blue-100 rounded-lg p-4">
                        @include('_friends-list')
                </div>
         </div>

@endsection

</x-app-layout>

