<div class="flex p-4 border-b border-b-gray-400">
    <div class="mr-2">
        <a href="{{ route('profile', $tweet->user->name) }}">
            <div class="flex mb-4 font-bold">
                <img class="rounded-full mr-2" src="https://i.pravatar.cc/40" alt="">
                {{ $tweet->user->name }}
            </div>
        </a>

        <div>
            <p class="text-sm mr-3">{{ $tweet->body }} </p>
        </div>
    </div>
</div>

