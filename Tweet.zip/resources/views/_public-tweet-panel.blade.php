<div class="border border-blue-400 rounded-lg px-8 py-6 mb-4">
    <form method="POST" action="/tweets">
        @csrf
            <textarea name="body" class="w-full border-none" placeholder="What's up doc!"></textarea>

            <hr class="my-4">

            <footer class="flex justify-between">
                    <img class="rounded-full mr-2" src="https://i.pravatar.cc/40" alt="">
                    <button type="submit" class="bg-blue-500 rounded-lg py-2 px-2 text-white shadow">Tweet-a-boo!</button>
            </footer>
    </form>

    @error('body')
            <p style="color: red">{{ $message }}</p>
    @enderror
</div>